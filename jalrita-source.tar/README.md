# Jalrita 2.0 — connected citizen and administrator app

## Included

- `/citizen`: live OpenStreetMap, real community reports, Google login, photo/pin/GPS submissions, private report tracking, confirmations and weather.
- `/admin`: separate sign-in/access page and response queue, staff-only team/status/note updates, private response history.
- Android app `org.jalrita.app`: Android 8+, Google Credential Manager account chooser, nonce-bound ID-token verification on the server, HttpOnly sessions, photo picker and permission-based GPS. It uses the same hosted app and database as the website. It has no sample data, local demo accounts, role switch or offline submission simulation.
- Server: local SQLite/disk or hosted PostgreSQL/private Supabase photo storage, sanitised image uploads, origin and host validation, role enforcement, append-only response events, session expiry, rate limits, security headers and `/healthz`.
- Dockerfile, Render free-service blueprint, Android Gradle wrapper and release build script.

## Current setup on this laptop

The configured local address is `http://localhost:3001/citizen`; administration is at `http://localhost:3001/admin`. Google Cloud project `jalrita` and separate web and Android OAuth clients have been created. The web credentials are in the local private `.env` and are intentionally excluded from this source archive and the APK. The owner's Google account is the initial test user and approved administrator.

The Google application is still in **Testing**. Browser consent and Android device sign-in must be completed and verified. The Render/Supabase sign-ins and hosted deployment must be finished before this is an internet-connected production release. Do not describe an unverified deployment as production-ready.

## Run the supplied source locally

Install Node.js 24+, extract this archive, then:

```powershell
npm ci
Copy-Item .env.example .env
# Fill in your own Google credentials and approved staff/support emails locally.
npm run build
npm test
npm start
```

Or use `START-JALRITA.cmd` after configuring `.env`. The default source configuration uses port 3000; the already-configured workspace on this laptop uses 3001. Register the exact matching Google callback, such as `http://localhost:3001/auth/google/callback`. Keep the server running. SQLite and photos survive restarts in `data/`. They are not included in the source archive.

## Free hosting arrangement

The deployment configuration supports Render's free Node server with a Supabase free PostgreSQL database and private Storage bucket. Accounts, credentials and quotas still apply. This arrangement is designed to avoid storing durable reports on Render's ephemeral filesystem. Free tiers can sleep/pause and are not a high-availability service commitment. No paid plan or billing has been enabled by this project.

1. In Supabase, create a Free project. Keep the database password private. Use its session-pooler Postgres connection string as `DATABASE_URL`; retain TLS certificate verification.
2. Create a **private** bucket called `incident-photos`. Set a 5 MB upload limit and allow JPEG, PNG and WebP where the dashboard supports it. The server uploads sanitised WebP only. Copy the project URL and server-side service-role key into the host's secret environment settings. Never put that key in the browser or Android app.
3. Deploy this source to Render through a private Git repository or the supplied blueprint. Choose **Free**, not a paid database/disk. Configure `APP_URL` with its HTTPS address, `NODE_ENV=production`, `HOST=0.0.0.0`, `DATABASE_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_STORAGE_BUCKET`, Google client ID/secret, `AUTHORITY_EMAILS` and `SUPPORT_EMAIL`.
4. Add `https://YOUR-JALRITA-HOST/auth/google/callback` to the existing web OAuth client. Set the homepage, privacy and terms URLs in Google branding to your deployed domain. Complete any Google verification requirements and publish the Google audience when ready for public users.
5. Check `/healthz`, real citizen login, an unauthorised account's denied admin access, a real report/photo, staff response history and persistence after restarting the host.
6. Build Android with the same HTTPS origin preconfigured. The release script now refuses an empty/placeholder address, an unreachable backend, or missing Google configuration. The APK already delivered before deployment displays an operator connection screen; it is not the final end-user release. The replacement must open the community homepage directly.

Hosted startup intentionally fails if mandatory Google, HTTPS, admin/support or durable-storage settings are missing. For an alternative host with an actual mounted persistent volume, SQLite/disk can be used by explicitly setting `PERSISTENT_DATA=true` and `DATA_DIR` to that volume.

## Android build and identity

Package: `org.jalrita.app`, replacement version 2.0.1 (not built until deployment), target Android API 35, minimum API 26. The previously delivered unconfigured APK is version 2.0.0.

Release signing certificate SHA-1:

```text
79:AF:9E:19:63:3D:58:80:E1:7D:42:B6:22:ED:96:DA:FE:BC:9F:B5
```

This certificate and package have been registered in the Android OAuth client in project `jalrita`. The Google Credential Manager requests the web/backend client ID as the ID-token audience; the backend verifies the signature, audience, expiry, verified email and one-time nonce before issuing its session.

Use JDK 17+ supported by Gradle 9.3.1, Android SDK platform 35 and build-tools 36.0.0. To rebuild with your saved private signing files:

```powershell
$env:JALRITA_APP_URL='https://YOUR-JALRITA-HOST'
./android/build-release.ps1 -Sdk 'C:\path\to\sdk' -Jdk 'C:\path\to\jdk' -Output 'Jalrita.apk'
```

`android/signing.private.json` and `android/release.keystore` are private and excluded from source distribution. A private backup is retained in `C:\Users\kcktu\Documents\Codex\Jalrita-Private`. Preserve these files for app updates; do not submit them to college, GitHub, Render source or an app store as project assets. For Play Store app signing, also register the Play signing certificate with Google; a different certificate is a different Android identity.

## Verification and remaining launch checks

The web production build, signed Android build, APK signature verification and automated suite pass. Tests cover origin/authentication/role checks, persistence, sanitised images, one confirmation per account, private histories, web OAuth state/PKCE, native nonce/audience/replay rejection, and PostgreSQL schema/atomic updates/RLS in a local PostgreSQL engine.

Mocked identity tests are not proof of a real Google login. A signed APK build is not proof of physical-device behavior. Complete actual Google consent, phone testing, hosted database/storage connectivity, backup/restore rehearsal and operator review before public launch. No live municipal integration or guaranteed emergency response is represented.

## Operations

- Back up the database and photo storage together. Free provider plans must not be assumed to include automatic backups. For local SQLite, stop the server and back up the entire `data` directory; for Postgres use a consistent database export plus bucket export. Test restoration before accepting important reports.
- Public incident queries currently show the most recent 500 reports. Add pagination and aggregate counts before a larger deployment. Weather comes from Open-Meteo and is modelled data.
- Per-process rate limits are appropriate for a small single-instance pilot; use shared rate-limit storage and trusted-proxy configuration before scaling to multiple instances.
- Monitor `/healthz` and server error logs. Keep dependencies and Android target SDK current. Define retention, moderation and account-deletion handling for the actual operator.
- Photos and locations are public observations; author account details, sessions, credentials and response history remain restricted. The server enables RLS on its PostgreSQL tables so Supabase's anonymous API cannot expose them; only the server uses privileged database/storage credentials.

Official references: https://developers.google.com/identity/protocols/oauth2/web-server ; https://developer.android.com/identity/sign-in/credential-manager-siwg ; https://operations.osmfoundation.org/policies/tiles/ ; https://render.com/docs/free ; https://supabase.com/pricing
