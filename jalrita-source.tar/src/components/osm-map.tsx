import {useEffect,useRef,useState} from 'react';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {colours,type Incident} from '@/lib/incidents';
type Props={incidents:Incident[];onSelect:(i:Incident)=>void;focus?:[number,number];heat?:boolean;onPick?:(p:[number,number])=>void};
export default function FloodMap(props:Props){
 const el=useRef<HTMLDivElement>(null),map=useRef<L.Map|null>(null),layers=useRef<L.LayerGroup|null>(null),callbacks=useRef(props);
 const [ready,setReady]=useState(false),[error,setError]=useState(false);callbacks.current=props;
 useEffect(()=>{if(!el.current)return;const m=L.map(el.current,{zoomControl:false,scrollWheelZoom:false}).setView([19.294,72.86],13);map.current=m;
 L.control.zoom({position:'bottomright'}).addTo(m);
 const tiles=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>'}).addTo(m);
 tiles.on('tileerror',()=>setError(true));tiles.on('tileload',()=>setError(false));
 layers.current=L.layerGroup().addTo(m);m.on('click',e=>callbacks.current.onPick?.([e.latlng.lng,e.latlng.lat]));
 const resize=new ResizeObserver(()=>m.invalidateSize());resize.observe(el.current);setReady(true);
 return()=>{resize.disconnect();m.remove();map.current=null;layers.current=null;};},[]);
 useEffect(()=>{if(!ready||!layers.current)return;layers.current.clearLayers();for(const i of props.incidents){if(props.heat)L.circle([i.lat,i.lng],{radius:350,stroke:false,fillColor:colours[i.severity],fillOpacity:.13,interactive:false}).addTo(layers.current);
 const label=document.createElement('span');label.textContent=i.location+' · '+i.severity;
 const marker=L.marker([i.lat,i.lng],{title:label.textContent,alt:label.textContent,icon:L.divIcon({className:'osm-marker',html:`<span style="background:${colours[i.severity]}"></span>`,iconSize:[26,26],iconAnchor:[13,13]}),bubblingMouseEvents:false}).bindTooltip(label).addTo(layers.current);marker.on('click',()=>callbacks.current.onSelect(i));}},[ready,props.incidents,props.heat]);
 useEffect(()=>{if(ready&&props.focus)map.current?.setView([props.focus[1],props.focus[0]],15);},[ready,props.focus]);
 return <div className="mapwrap"><div ref={el} className="mapcanvas" aria-label="OpenStreetMap of Mira Bhayandar"/>{error&&<div role="status" className="map-error">Map tiles unavailable. Check your internet connection; reports remain available.</div>}</div>;
}
