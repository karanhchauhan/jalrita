import {createRoot} from 'react-dom/client';
import App from './Platform';
import Legal from './Legal';
import './styles.css';
import './platform.css';
createRoot(document.getElementById('root')!).render(['/privacy','/terms'].includes(location.pathname)?<Legal/>:<App/>);
