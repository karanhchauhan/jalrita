export type Incident={id:string;location:string;lat:number;lng:number;severity:string;description:string;photo?:string;status:string;team:string;created:string;updated:string;confirmations:number;mine?:boolean};
export const colours:Record<string,string>={'Ankle-deep':'#e5ac22','Knee-deep':'#f07843','Impassable':'#e05262'};
