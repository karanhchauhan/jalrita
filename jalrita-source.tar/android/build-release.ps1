param([Parameter(Mandatory=$true)][string]$Sdk,[Parameter(Mandatory=$true)][string]$Jdk,[string]$Gradle=(Join-Path $PSScriptRoot 'gradlew.bat'),[string]$Output='Jalrita.apk',[string]$ServerUrl=$env:JALRITA_APP_URL)
$ErrorActionPreference='Stop'
# Do this before signing or copying any output: an unconfigured APK is not
# a usable citizen release.
if([string]::IsNullOrWhiteSpace($ServerUrl)){throw 'Release blocked: deploy Jalrita first, then provide its HTTPS address with -ServerUrl.'}
$serverUri=$null
if(![Uri]::TryCreate($ServerUrl,[UriKind]::Absolute,[ref]$serverUri) -or $serverUri.Scheme -ne 'https' -or $serverUri.UserInfo -or $serverUri.Query -or $serverUri.Fragment -or $serverUri.AbsolutePath -ne '/' -or $serverUri.IsLoopback){throw 'Release blocked: provide a valid HTTPS server origin, not localhost or a placeholder.'}
$ServerUrl=$serverUri.GetLeftPart([UriPartial]::Authority)
if($serverUri.Host -match '(^|\.)(example\.(com|org|net)|invalid)$' -or $serverUri.Host -eq 'your-jalrita-server'){throw 'Release blocked: a placeholder cannot be used as the server address.'}
try {
 $health=Invoke-RestMethod "$ServerUrl/healthz" -TimeoutSec 15
 $config=Invoke-RestMethod "$ServerUrl/api/config" -TimeoutSec 15
 $identity=Invoke-RestMethod "$ServerUrl/api/me" -TimeoutSec 15
 if($health.ok -ne $true -or $config.mapProvider -ne 'openstreetmap' -or $config.nativeGoogleConfigured -ne $true -or $identity.googleConfigured -ne $true){throw 'The server is not ready for the connected app.'}
} catch {throw 'Release blocked: the HTTPS Jalrita backend must be reachable with Google login configured.'}
$env:JAVA_HOME=$Jdk
$env:ANDROID_HOME=$Sdk
$secretFile=Join-Path $PSScriptRoot 'signing.private.json'
if(!(Test-Path $secretFile)){throw 'Provide signing.private.json with a strong password field, or provision your own release signing configuration.'}
$secret=Get-Content -Raw -LiteralPath $secretFile | ConvertFrom-Json
$env:JALRITA_STORE_PASSWORD=$secret.password
$env:JALRITA_KEYSTORE=Join-Path $PSScriptRoot 'release.keystore'
$previousAppUrl=$env:JALRITA_APP_URL
$env:JALRITA_APP_URL=$ServerUrl
try {
 if(!(Test-Path $env:JALRITA_KEYSTORE)) {
  & "$Jdk\bin\keytool.exe" -genkeypair -keystore $env:JALRITA_KEYSTORE -storepass:env JALRITA_STORE_PASSWORD -keypass:env JALRITA_STORE_PASSWORD -alias jalrita -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=Jalrita,O=Jalrita,C=IN'
  if($LASTEXITCODE -ne 0){throw 'Could not generate release signing key.'}
 }
 Push-Location $PSScriptRoot
 try {& $Gradle --no-daemon assembleRelease; if($LASTEXITCODE -ne 0){throw 'Android build failed.'}} finally {Pop-Location}
 $metadata=Get-Content -Raw -LiteralPath "$PSScriptRoot\build\outputs\apk\release\output-metadata.json" | ConvertFrom-Json
 $filename=$metadata.elements[0].outputFile
 if([IO.Path]::GetFileName($filename) -ne $filename){throw 'Unexpected APK output path.'}
 Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\build\outputs\apk\release" $filename) -Destination $Output -Force
 & "$Sdk\build-tools\36.0.0\apksigner.bat" verify --verbose --print-certs $Output
 if($LASTEXITCODE -ne 0){throw 'APK signature verification failed.'}
} finally {Remove-Item Env:JALRITA_STORE_PASSWORD -ErrorAction SilentlyContinue; Remove-Item Env:JALRITA_KEYSTORE -ErrorAction SilentlyContinue; if($null -eq $previousAppUrl){Remove-Item Env:JALRITA_APP_URL -ErrorAction SilentlyContinue}else{$env:JALRITA_APP_URL=$previousAppUrl}}
