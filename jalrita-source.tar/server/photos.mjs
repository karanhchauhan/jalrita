import {writeFile,readFile,unlink} from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
export function photoStore(dataDir){
 const origin=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY,bucket=process.env.SUPABASE_STORAGE_BUCKET||'incident-photos';
 if(!!origin!==!!key)throw Error('Configure both SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.');
 if(origin&&new URL(origin).protocol!=='https:')throw Error('Supabase storage must use HTTPS.');
 const headers={'apikey':key||'',Authorization:'Bearer '+(key||'')};
 async function remote(id,method,body){const r=await fetch(origin.replace(/\/$/,'')+'/storage/v1/object/'+encodeURIComponent(bucket)+'/'+id,{method,headers:{...headers,...(body?{'Content-Type':'image/webp','x-upsert':'false'}:{})},body,signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('Photo storage unavailable');return r;}
 return {kind:origin?'supabase':'disk',
 async save(id,file){if(file.size>5*1024*1024||!['image/jpeg','image/png','image/webp'].includes(file.type))throw Object.assign(Error('Choose a JPG, PNG or WebP under 5 MB.'),{status:400});let bytes;try{bytes=await sharp(Buffer.from(await file.arrayBuffer()),{limitInputPixels:40e6,failOn:'error'}).rotate().resize({width:2048,height:2048,fit:'inside',withoutEnlargement:true}).webp({quality:82}).toBuffer();}catch{throw Object.assign(Error('The photo could not be decoded. Choose a valid image.'),{status:400});}if(origin)await remote(id,'POST',bytes);else await writeFile(path.join(dataDir,'uploads',id),bytes,{flag:'wx'});return 'image/webp';},
 async read(id){return origin?Buffer.from(await(await remote(id,'GET')).arrayBuffer()):readFile(path.join(dataDir,'uploads',id));},
 async remove(id){if(origin)await remote(id,'DELETE');else await unlink(path.join(dataDir,'uploads',id));}};
}
