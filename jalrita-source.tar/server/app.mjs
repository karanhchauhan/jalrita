import http from 'node:http';
import {randomBytes,randomUUID,createHash,timingSafeEqual} from 'node:crypto';
import {readFile,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {OAuth2Client} from 'google-auth-library';
import {openStore} from './store.mjs';
import {photoStore} from './photos.mjs';
import {nativeAuth} from './native-auth.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1';
const appURL=new URL(process.env.APP_URL||'http://localhost:3000'),secure=appURL.protocol==='https:',production=process.env.NODE_ENV==='production';
const googleConfigured=!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET),nativeConfigured=!!process.env.GOOGLE_CLIENT_ID;
if(production&&(!secure||!googleConfigured||!process.env.AUTHORITY_EMAILS||!process.env.SUPPORT_EMAIL))throw Error('Production needs HTTPS APP_URL, Google OAuth credentials, AUTHORITY_EMAILS and SUPPORT_EMAIL.');
if(production&&!process.env.DATABASE_URL&&process.env.PERSISTENT_DATA!=='true')throw Error('Production needs DATABASE_URL or explicitly provisioned persistent storage.');
if(production&&process.env.DATABASE_URL&&(!process.env.SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY))throw Error('Hosted database requires durable photo storage (Supabase).');
const allowed=new Set([appURL.origin,...(process.env.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean)]),hosts=new Set([...allowed].map(s=>new URL(s).host));
const store=await openStore(path.resolve(root,process.env.DATA_DIR||'data')),q=store.query,photos=photoStore(path.resolve(root,process.env.DATA_DIR||'data'));
const staff=new Set((process.env.AUTHORITY_EMAILS||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean));
const oauth=new OAuth2Client(process.env.GOOGLE_CLIENT_ID,process.env.GOOGLE_CLIENT_SECRET,appURL.origin+'/auth/google/callback');
const sha=s=>createHash('sha256').update(s).digest('hex'),isStaff=u=>!!u&&staff.has(u.email.toLowerCase());
const fail=(status,message)=>Object.assign(Error(message),{status});
function cookie(req,name){return (req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1)||'';}
function setCookie(res,name,value,age){const entry=`${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure?'; Secure':''}`;const old=res.getHeader('Set-Cookie');res.setHeader('Set-Cookie',[...(old?(Array.isArray(old)?old:[old]):[]),entry]);}
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
function redirect(res,url){res.writeHead(302,{Location:url,'Cache-Control':'no-store'});res.end();}
async function identity(req){const token=cookie(req,'jalarita_session');return token?(await q('SELECT u.id,u.email,u.name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?',[sha(token),Date.now()]))[0]||null:null;}
function requireOrigin(req){if(!allowed.has(req.headers.origin))throw fail(403,'Request origin is not allowed.');}
function requireUser(u){if(!u)throw fail(401,'Sign in with Google to continue.');return u;}
function requireAdmin(u){requireUser(u);if(!isStaff(u))throw fail(403,'Your account does not have administrator access.');return u;}
async function bytes(req,max=6*1024*1024){if(Number(req.headers['content-length']||0)>max)throw fail(413,'Request too large.');const chunks=[];let size=0;for await(const b of req){size+=b.length;if(size>max)throw fail(413,'Request too large.');chunks.push(b);}return Buffer.concat(chunks);}
async function payload(req){try{return JSON.parse((await bytes(req,16384)).toString());}catch(e){if(e.status)throw e;throw fail(400,'Invalid JSON request.');}}
const buckets=new Map();function rate(req,u,key,max){const bucket=key+':'+(u?.id||req.socket.remoteAddress),now=Date.now();let entry=buckets.get(bucket);if(!entry||entry.expires<now){entry={count:0,expires:now+3600000};buckets.set(bucket,entry);}if(++entry.count>max)throw fail(429,'Too many requests. Try again later.');}
async function saveIdentity(p){await q('INSERT INTO users(id,email,name) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,name=excluded.name',[p.sub,p.email,p.name||p.email]);}
async function issueSession(res,id){const token=randomBytes(32).toString('base64url');await q('INSERT INTO sessions VALUES(?,?,?)',[sha(token),id,Date.now()+7*86400000]);setCookie(res,'jalarita_session',token,7*86400);}
const native=nativeAuth({query:q,client:oauth,clientId:process.env.GOOGLE_CLIENT_ID,saveIdentity,issueSession});
let weatherCache;const dev=process.argv.includes('--dev');let vite;
if(dev){const {createServer}=await import('vite');vite=await createServer({root,server:{middlewareMode:true,allowedHosts:[...hosts].map(s=>s.split(':')[0])},appType:'spa'});}
const cleanup=setInterval(async()=>{try{for(const table of ['sessions','oauth_states','native_challenges'])await q('DELETE FROM '+table+' WHERE expires<?',[Date.now()]);await q('DELETE FROM oauth_destinations WHERE token NOT IN (SELECT token FROM oauth_states)');for(const [k,v]of buckets)if(v.expires<Date.now())buckets.delete(k);}catch{console.error('Session cleanup failed.');}},600000);cleanup.unref();
async function incidents(u,mine=false){const rows=await q('SELECT i.*, (SELECT count(*) FROM confirmations c WHERE c.incident=i.id) AS confirmations FROM incidents i'+(mine?' WHERE i.owner=?':'')+' ORDER BY created DESC LIMIT 500',mine?[u.id]:[]);return rows.map(({owner,photo_type,...i})=>({...i,confirmations:Number(i.confirmations),mine:owner===u?.id}));}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(self)');
 if(!dev)res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://tile.openstreetmap.org; connect-src 'self' https://tile.openstreetmap.org; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-src 'none'; frame-ancestors 'none'; form-action 'self'");
 if(production)res.setHeader('Strict-Transport-Security','max-age=31536000');
 try{
 if(!hosts.has(req.headers.host))throw fail(403,'Unrecognised host.');
 const url=new URL(req.url,appURL),route=url.pathname,method=req.method;
 if(route==='/healthz'){await q('SELECT 1');return json(res,200,{ok:true});}
 const u=await identity(req);
 if(route==='/api/config'&&method==='GET')return json(res,200,{mapProvider:'openstreetmap',nativeGoogleConfigured:nativeConfigured,supportEmail:process.env.SUPPORT_EMAIL||''});
 if(route==='/api/me'&&method==='GET')return json(res,200,{user:u?{name:u.name,email:u.email}:null,googleConfigured,canManage:isStaff(u),role:isStaff(u)?'admin':u?'citizen':null});
 if(route==='/auth/native/challenge'&&method==='POST'){requireOrigin(req);rate(req,u,'native-login',30);if(!nativeConfigured)throw fail(503,'Google login has not been configured.');return json(res,200,await native.challenge());}
 if(route==='/auth/native/exchange'&&method==='POST'){requireOrigin(req);rate(req,u,'native-exchange',60);const result=await native.exchange(await payload(req),res);const previous=cookie(req,'jalarita_session');if(previous)await q('DELETE FROM sessions WHERE token=?',[sha(previous)]);return json(res,200,result);}
 if(route==='/auth/google'&&method==='GET'){
 if(!googleConfigured)throw fail(503,'Google sign-in is not configured yet.');
 if(req.headers.host!==appURL.host)return redirect(res,appURL.origin+'/auth/google');rate(req,u,'login',30);
 const state=randomBytes(32).toString('base64url'),nonce=randomBytes(32).toString('base64url'),verifier=randomBytes(32).toString('base64url');await q('INSERT INTO oauth_states VALUES(?,?,?,?)',[sha(state),nonce,verifier,Date.now()+600000]);await q('INSERT INTO oauth_destinations VALUES(?,?)',[sha(state),url.searchParams.get('portal')==='admin'?'/admin':'/citizen']);setCookie(res,'jalarita_oauth',state,600);
 return redirect(res,oauth.generateAuthUrl({scope:['openid','email','profile'],state,nonce,code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256',prompt:'select_account'}));}
 if(route==='/auth/google/callback'&&method==='GET'){
 const state=url.searchParams.get('state')||'',a=Buffer.from(state),b=Buffer.from(cookie(req,'jalarita_oauth'));if(!state||a.length!==b.length||!timingSafeEqual(a,b))throw fail(400,'Invalid sign-in state. Start sign-in again.');
 const saved=(await q('DELETE FROM oauth_states WHERE token=? AND expires>? RETURNING *',[sha(state),Date.now()]))[0];if(!saved)throw fail(400,'Sign-in expired. Start again.');const destination=(await q('DELETE FROM oauth_destinations WHERE token=? RETURNING destination',[sha(state)]))[0]?.destination||'/citizen';setCookie(res,'jalarita_oauth','',0);
 if(url.searchParams.has('error'))return redirect(res,destination+'?auth_error=cancelled');
 try{const code=url.searchParams.get('code');if(!code)throw Error();const {tokens}=await oauth.getToken({code,codeVerifier:saved.verifier});if(!tokens.id_token)throw Error();const ticket=await oauth.verifyIdToken({idToken:tokens.id_token,audience:process.env.GOOGLE_CLIENT_ID});const p=ticket.getPayload();if(!p?.sub||!p.email||!p.email_verified||p.nonce!==saved.nonce)throw Error();await saveIdentity(p);const old=cookie(req,'jalarita_session');if(old)await q('DELETE FROM sessions WHERE token=?',[sha(old)]);await issueSession(res,p.sub);return redirect(res,destination);}catch{console.error('Google authentication failed.');return redirect(res,destination+'?auth_error=failed');}}
 if(route==='/auth/logout'&&method==='POST'){requireOrigin(req);requireUser(u);await q('DELETE FROM sessions WHERE token=?',[sha(cookie(req,'jalarita_session'))]);setCookie(res,'jalarita_session','',0);return json(res,200,{ok:true});}
 if(route==='/api/admin/summary'&&method==='GET'){requireAdmin(u);const counts=await q('SELECT status,count(*) AS count FROM incidents GROUP BY status');return json(res,200,{counts:counts.map(r=>({...r,count:Number(r.count)}))});}
 if(route==='/api/admin/incidents'&&method==='GET'){requireAdmin(u);return json(res,200,{incidents:await incidents(u),canManage:true});}
 if(route==='/api/incidents'&&method==='GET'){const mine=url.searchParams.get('mine')==='true';if(mine)requireUser(u);return json(res,200,{incidents:await incidents(u,mine),canManage:isStaff(u)});}
 if(/^\/api\/incidents\/[^/]+\/history$/.test(route)&&method==='GET'){requireUser(u);const id=route.split('/')[3],report=(await q('SELECT owner FROM incidents WHERE id=?',[id]))[0];if(!report)throw fail(404,'Report not found.');if(report.owner!==u.id&&!isStaff(u))throw fail(403,'This report history is private.');const events=await q('SELECT a.action,a.status,a.team,a.note,a.created,u.name AS actor FROM audit_events a JOIN users u ON u.id=a.actor WHERE a.incident=? ORDER BY a.created ASC',[id]);return json(res,200,{events});}
 if(route==='/api/incidents'&&method==='POST'){
 requireOrigin(req);requireUser(u);rate(req,u,'report',30);let f;try{f=await new Request(appURL,{method:'POST',headers:{'Content-Type':req.headers['content-type']||''},body:await bytes(req)}).formData();}catch(e){if(e.status)throw e;throw fail(400,'Invalid report form.');}
 const location=String(f.get('location')||'').trim(),description=String(f.get('description')||'').trim(),severity=String(f.get('severity')),lat=Number(f.get('lat')),lng=Number(f.get('lng'));
 if(!location||location.length>150||description.length>2000||!['Ankle-deep','Knee-deep','Impassable'].includes(severity)||!Number.isFinite(lat)||!Number.isFinite(lng)||lat<19.20||lat>19.36||lng<72.75||lng>72.96)throw fail(400,'Enter a valid location within Mira Bhayandar and severity.');
 const id=randomUUID(),now=new Date().toISOString();let photo=null,photoType=null;const file=f.get('photo');if(file instanceof File&&file.size){photoType=await photos.save(id,file);photo=id;}
 try{await q('INSERT INTO incidents(id,owner,location,lat,lng,severity,description,photo,photo_type,status,team,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',[id,u.id,location,lat,lng,severity,description,photo,photoType,'Reported','Unassigned',now,now]);}catch(e){if(photo)await photos.remove(photo).catch(()=>{});throw e;}
 return json(res,201,{id});}
 if(route==='/api/incidents'&&method==='PATCH'){
 requireOrigin(req);requireUser(u);rate(req,u,'update',120);const p=await payload(req);if(!p||typeof p.id!=='string')throw fail(400,'Invalid report ID.');const existing=(await q('SELECT * FROM incidents WHERE id=?',[p.id]))[0];if(!existing)throw fail(404,'Report not found.');
 if(p.action==='confirm')await q('INSERT INTO confirmations(incident,owner) VALUES(?,?) ON CONFLICT(incident,owner) DO NOTHING',[p.id,u.id]);
 else{requireAdmin(u);if(p.action!=='manage'||!['Reported','Assigned','In progress','Resolved'].includes(p.status)||typeof p.team!=='string'||p.team.length>120||typeof(p.note||'')!=='string'||(p.note||'').length>1000)throw fail(400,'Invalid status, team or note.');const now=new Date().toISOString();
 // An append-only response event and the current queue state are stored in
 // one SQL statement on Postgres. SQLite uses an explicit transaction below.
 if(store.kind==='postgres')await q('WITH changed AS (UPDATE incidents SET status=?,team=?,updated=? WHERE id=? RETURNING id) INSERT INTO audit_events(id,incident,actor,action,status,team,note,created) SELECT ?,id,?,?,?,?,?,? FROM changed',[p.status,p.team,now,p.id,randomUUID(),u.id,'manage',p.status,p.team,p.note||'',now]);
 else store.manage(p.id,u.id,p.status,p.team,p.note||'',now,randomUUID());}
 return json(res,200,{ok:true});}
 if(route.startsWith('/api/photos/')&&method==='GET'){const id=route.split('/').at(-1);if(!/^[a-z0-9-]{36}$/.test(id))throw fail(404,'Photo not found.');const row=(await q('SELECT photo_type FROM incidents WHERE photo=?',[id]))[0];if(!row)throw fail(404,'Photo not found.');res.writeHead(200,{'Content-Type':row.photo_type,'Cache-Control':'private, max-age=3600'});return res.end(await photos.read(id));}
 if(route==='/api/weather'&&method==='GET'){if(weatherCache?.expires>Date.now())return json(res,200,weatherCache.data);try{const r=await fetch('https://api.open-meteo.com/v1/forecast?latitude=19.29&longitude=72.86&current=temperature_2m,rain&timezone=Asia%2FKolkata',{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error();const d=await r.json(),data={temperature:d.current.temperature_2m,rain:d.current.rain,time:d.current.time,interval:d.current.interval,source:'Open-Meteo'};weatherCache={data,expires:Date.now()+600000};return json(res,200,data);}catch{throw fail(503,'Weather is temporarily unavailable.');}}
 if(route.startsWith('/api/')||route.startsWith('/auth/'))throw fail(404,'Endpoint not found.');
 if(vite)return vite.middlewares(req,res,()=>json(res,404,{error:'Page not found.'}));
 if(!['GET','HEAD'].includes(method))throw fail(405,'Method not allowed.');
 const dist=path.join(root,'dist'),asset=path.resolve(dist,'.'+decodeURIComponent(route));if(asset!==dist&&!asset.startsWith(dist+path.sep))throw fail(403,'Forbidden');let target=asset;try{if(!(await stat(target)).isFile())target=path.join(dist,'index.html');}catch{if(path.extname(route))throw fail(404,'File not found.');target=path.join(dist,'index.html');}
 const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.json':'application/json'};res.writeHead(200,{'Content-Type':mime[path.extname(target)]||'application/octet-stream','Cache-Control':target.includes(path.sep+'assets'+path.sep)?'public, max-age=31536000, immutable':'no-cache'});return res.end(method==='HEAD'?undefined:await readFile(target));
 }catch(e){if(res.headersSent){res.destroy();return;}if(!e.status)console.error('Request failed:',e.code||e.name);json(res,e.status||500,{error:e.status?e.message:'Request failed. Please try again.'});}
});
server.requestTimeout=30000;server.headersTimeout=15000;
server.listen(port,host,()=>console.log(`JALARITA running at ${appURL.origin}\nStorage: ${store.kind}, photos: ${photos.kind}\nGoogle sign-in: ${googleConfigured?'configured':'credentials required'}`));
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port is already in use. Stop the other server or change PORT.':'Server could not start.');process.exit(1);});
async function close(){clearInterval(cleanup);server.close();await vite?.close();await store.close();process.exit(0);}process.on('SIGINT',close);process.on('SIGTERM',close);
