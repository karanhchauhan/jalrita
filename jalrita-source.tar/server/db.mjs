import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
export function openDatabase(dataDir){mkdirSync(dataDir,{recursive:true});mkdirSync(path.join(dataDir,'uploads'),{recursive:true});const db=new DatabaseSync(path.join(dataDir,'jalarita.sqlite'));db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY,email TEXT NOT NULL,name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS oauth_states (token TEXT PRIMARY KEY,nonce TEXT NOT NULL,verifier TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES users(id),location TEXT NOT NULL,lat REAL NOT NULL,lng REAL NOT NULL,severity TEXT NOT NULL,description TEXT NOT NULL,photo TEXT,photo_type TEXT,status TEXT NOT NULL DEFAULT 'Reported',team TEXT NOT NULL DEFAULT 'Unassigned',created TEXT NOT NULL,updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS confirmations (incident TEXT NOT NULL REFERENCES incidents(id),owner TEXT NOT NULL REFERENCES users(id),PRIMARY KEY(incident,owner));
CREATE INDEX IF NOT EXISTS incidents_created_idx ON incidents(created);
PRAGMA user_version=1;`);return db;}
