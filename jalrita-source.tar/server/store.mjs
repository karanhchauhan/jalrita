import {openDatabase} from './db.mjs';
import pg from 'pg';
import {readFileSync} from 'node:fs';
import {rootCertificates} from 'node:tls';
function connectionOptions(){
 const url=new URL(process.env.DATABASE_URL);
 // pg's connection-string SSL parameters otherwise replace the explicit CA
 // configuration. This app always verifies the database certificate/host.
 for(const name of ['sslmode','sslrootcert','sslcert','sslkey'])url.searchParams.delete(name);
 return {connectionString:url.href,ssl:{rejectUnauthorized:true,ca:[...rootCertificates,readFileSync(new URL('./certs/supabase-ca.crt',import.meta.url),'utf8')]},max:5,connectionTimeoutMillis:10000,idleTimeoutMillis:30000};
}
export async function openStore(dataDir,poolOverride){
 if(!process.env.DATABASE_URL&&!poolOverride){const db=openDatabase(dataDir);db.exec(extraSchema);return {query:async(sql,args=[])=>{const statement=db.prepare(sql);return /^(SELECT|WITH)|RETURNING/i.test(sql)?statement.all(...args):statement.run(...args);},manage(id,actor,status,team,note,now,eventId){db.exec('BEGIN IMMEDIATE');try{db.prepare('UPDATE incidents SET status=?,team=?,updated=? WHERE id=?').run(status,team,now,id);db.prepare('INSERT INTO audit_events VALUES(?,?,?,?,?,?,?,?)').run(eventId,id,actor,'manage',status,team,note,now);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}},close:async()=>db.close(),kind:'sqlite'};}
 const pool=poolOverride||new pg.Pool(connectionOptions());
 const query=async(sql,args=[])=>{let i=0;const result=await pool.query(sql.replace(/\?/g,()=>'$'+(++i)),args);return result.rows;};
 await pool.query(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY,email TEXT NOT NULL,name TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires BIGINT NOT NULL);
 CREATE TABLE IF NOT EXISTS oauth_states (token TEXT PRIMARY KEY,nonce TEXT NOT NULL,verifier TEXT NOT NULL,expires BIGINT NOT NULL);
 CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES users(id),location TEXT NOT NULL,lat DOUBLE PRECISION NOT NULL,lng DOUBLE PRECISION NOT NULL,severity TEXT NOT NULL,description TEXT NOT NULL,photo TEXT,photo_type TEXT,status TEXT NOT NULL DEFAULT 'Reported',team TEXT NOT NULL DEFAULT 'Unassigned',created TEXT NOT NULL,updated TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS confirmations (incident TEXT NOT NULL REFERENCES incidents(id),owner TEXT NOT NULL REFERENCES users(id),PRIMARY KEY(incident,owner));
 CREATE INDEX IF NOT EXISTS incidents_created_idx ON incidents(created);`+extraSchema);
 // All data access goes through this server. Supabase's public API must not
 // expose sessions or private profile information to anonymous SDK clients.
 for(const table of ['users','sessions','oauth_states','incidents','confirmations','audit_events','native_challenges','oauth_destinations'])await pool.query('ALTER TABLE '+table+' ENABLE ROW LEVEL SECURITY');
 return {query,close:()=>pool.end(),kind:'postgres'};
}
const extraSchema=`
 CREATE TABLE IF NOT EXISTS audit_events (id TEXT PRIMARY KEY,incident TEXT NOT NULL REFERENCES incidents(id),actor TEXT NOT NULL REFERENCES users(id),action TEXT NOT NULL,status TEXT NOT NULL,team TEXT NOT NULL,note TEXT NOT NULL,created TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS audit_incident_idx ON audit_events(incident,created);
 CREATE TABLE IF NOT EXISTS native_challenges (token TEXT PRIMARY KEY,nonce TEXT NOT NULL,expires BIGINT NOT NULL);
 CREATE TABLE IF NOT EXISTS oauth_destinations (token TEXT PRIMARY KEY,destination TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires);`;
