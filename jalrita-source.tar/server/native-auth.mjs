import {randomBytes,createHash} from 'node:crypto';
const hash=s=>createHash('sha256').update(s).digest('hex');
export function nativeAuth({query,client,clientId,saveIdentity,issueSession}){
 return {async challenge(){const id=randomBytes(32).toString('base64url'),nonce=randomBytes(32).toString('base64url');await query('INSERT INTO native_challenges VALUES(?,?,?)',[hash(id),nonce,Date.now()+180000]);return {challengeId:id,nonce,webClientId:clientId};},
 async exchange({challengeId,idToken},res){if(typeof challengeId!=='string'||typeof idToken!=='string'||idToken.length>12000)throw Object.assign(Error('Invalid sign-in request.'),{status:400});const row=(await query('SELECT * FROM native_challenges WHERE token=? AND expires>?',[hash(challengeId),Date.now()]))[0];if(!row)throw Object.assign(Error('Sign-in expired. Try again.'),{status:400});let p;try{const ticket=await client.verifyIdToken({idToken,audience:clientId});p=ticket.getPayload();if(!p?.sub||!p.email||!p.email_verified||p.nonce!==row.nonce)throw Error();}catch{throw Object.assign(Error('Google identity verification failed.'),{status:401});}
 const consumed=await query('DELETE FROM native_challenges WHERE token=? RETURNING token',[hash(challengeId)]);if(!consumed.length)throw Object.assign(Error('Sign-in already used.'),{status:400});await saveIdentity(p);await issueSession(res,p.sub);return {ok:true};}};
}
