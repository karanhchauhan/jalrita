@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 or later, then run this file again.
 pause
 exit /b 1
)
if not exist node_modules (
 call npm.cmd ci
 if errorlevel 1 exit /b 1
)
echo Jalrita will print its local address below. Keep this window open.
call npm.cmd start
pause
